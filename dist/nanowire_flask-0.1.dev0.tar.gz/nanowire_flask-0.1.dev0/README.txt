Nanowire flask

This library is designed to allow a python developer to easily create a nanowire plugin using the flask APIs structure.

At the moment it can only handle images however it will soon be expanded to handle text.
