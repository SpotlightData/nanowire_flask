#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 20 11:32:34 2019

@author: stuart
"""

#nanowire_flask json tools